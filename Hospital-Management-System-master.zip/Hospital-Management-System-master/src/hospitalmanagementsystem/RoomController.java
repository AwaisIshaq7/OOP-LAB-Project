package hospitalmanagementsystem;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class RoomController implements Initializable {

    @FXML
    private Button goBack;
    @FXML
    private TableView<Room> tableRoom;
    @FXML
    private TableColumn<Room, Integer> roomID;
    @FXML
    private TableColumn<Room, String> roomType;
    @FXML
    private TableColumn<Room, String> roomPatient;
    @FXML
    private TableColumn<Room, String> appointedDoctor;
    @FXML
    private TableColumn<Room, String> patientProblem;
    @FXML
    private TextField txtRoomNo;
    @FXML
    private TextField txtRoomType;
    @FXML
    private ComboBox<String> comboPatientInfo;
    @FXML
    private ComboBox<String> comboAppointedDoctor;
    @FXML
    private ComboBox<String> comboPatientProblem;
    @FXML
    private Button btnRoomNo;
    @FXML
    private Button btnRoomType;
    @FXML
    private Button btnPatientInfo;
    @FXML
    private Button btnAppointedDoctor;
    @FXML
    private Button btnPatientProblem;
    @FXML
    private Button btnAddPatient;
    @FXML
    private Button btnUpdatePatient;
    @FXML
    private Button btnDischargePatient;

    private Connection conn = null;
    private PreparedStatement prst = null;
    private ResultSet rs = null;
    private ObservableList<Room> roomList;
    private ObservableList<String> patientList;
    private ObservableList<String> doctorList;
    private ObservableList<String> patientProblemList;

    public void backAction(ActionEvent e) throws IOException {
        goBack.getScene().getWindow().hide();

        Stage back = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Welcome.fxml")));
        Scene scene = new Scene(root);
        back.setScene(scene);
        back.show();
        back.setResizable(false);
    }

    @FXML
    private void roomNoAction(ActionEvent e) {
        // Implement roomNoAction logic to handle Room No text field and button
    }

    @FXML
    private void roomTypeAction(ActionEvent e) {
        // Implement roomTypeAction logic to handle Room Type text field and button
    }

    @FXML
    private void patientInfoAction(ActionEvent e) {
        // Implement patientInfoAction logic to handle Patient Information text field and button
    }

    @FXML
    private void appointedDoctorAction(ActionEvent e) {
        // Implement appointedDoctorAction logic to handle Appointed Doctor text field and button
    }

    @FXML
    private void patientProblemAction(ActionEvent e) {
        // Implement patientProblemAction logic to handle Patient Problem text field and button
    }

    @FXML
    private void addPatientAction(ActionEvent e) {
        String roomNo = txtRoomNo.getText();
        String roomType = txtRoomType.getText();
        String patientInfo = comboPatientInfo.getValue();
        String appointedDoctor = comboAppointedDoctor.getValue();
        String patientProblem = comboPatientProblem.getValue();

        // Input validation
        if (roomNo.isEmpty() || roomType.isEmpty() || patientInfo == null || patientInfo.isEmpty() ||
                appointedDoctor == null || appointedDoctor.isEmpty() || patientProblem == null || patientProblem.isEmpty()) {
            // Show error message or handle empty input
            System.out.println("Please fill all the fields.");
            return;
        }

        try {
            int roomID = Integer.parseInt(roomNo);
            Room newRoom = new Room(roomID, roomType, patientInfo, appointedDoctor, patientProblem);

            // Add to the database
            addRoomToDatabase(newRoom);

            // Add to the observable list
            roomList.add(newRoom);

            // Clear input fields
            txtRoomNo.clear();
            txtRoomType.clear();
            comboPatientInfo.getSelectionModel().clearSelection();
            comboAppointedDoctor.getSelectionModel().clearSelection();
            comboPatientProblem.getSelectionModel().clearSelection();

        } catch (NumberFormatException ex) {
            // Handle invalid input for room number
            System.out.println("Invalid room number. Please enter a valid number.");
        }
    }

    private void addRoomToDatabase(Room room) {
        String insertQuery = "INSERT INTO room (roomID, roomType, roomPatient, appointedDoctor, patientProblem) VALUES (?, ?, ?, ?, ?)";
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement(insertQuery);
            prst.setInt(1, room.getRoomID());
            prst.setString(2, room.getRoomType());
            prst.setString(3, room.getRoomPatient());
            prst.setString(4, room.getAppointedDoctor());
            prst.setString(5, room.getPatientProblem());
            prst.executeUpdate();
            prst.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void updatePatientAction(ActionEvent e) {
        String roomNo = txtRoomNo.getText();
        String roomType = txtRoomType.getText();
        String patientInfo = comboPatientInfo.getValue();
        String appointedDoctor = comboAppointedDoctor.getValue();
        String patientProblem = comboPatientProblem.getValue();

        // Input validation
        if (roomNo.isEmpty() || roomType.isEmpty() || patientInfo == null || patientInfo.isEmpty() ||
                appointedDoctor == null || appointedDoctor.isEmpty() || patientProblem == null || patientProblem.isEmpty()) {
            // Show error message or handle empty input
            System.out.println("Please fill all the fields.");
            return;
        }

        try {
            int roomID = Integer.parseInt(roomNo);

            // Find the room in the list
            for (Room room : roomList) {
                if (room.getRoomID() == roomID) {
                    // Update the room details
                    room.setRoomType(roomType);
                    room.setRoomPatient(patientInfo);
                    room.setAppointedDoctor(appointedDoctor);
                    room.setPatientProblem(patientProblem);

                    // Update the database
                    updateRoomInDatabase(room);

                    // Refresh the table view
                    tableRoom.refresh();

                    // Clear input fields
                    txtRoomNo.clear();
                    txtRoomType.clear();
                    comboPatientInfo.getSelectionModel().clearSelection();
                    comboAppointedDoctor.getSelectionModel().clearSelection();
                    comboPatientProblem.getSelectionModel().clearSelection();

                    return;
                }
            }

            // If the room was not found
            System.out.println("Room not found. Please enter a valid room number.");

        } catch (NumberFormatException ex) {
            // Handle invalid input for room number
            System.out.println("Invalid room number. Please enter a valid number.");
        }
    }

    private void updateRoomInDatabase(Room room) {
        String updateQuery = "UPDATE room SET roomType = ?, roomPatient = ?, appointedDoctor = ?, patientProblem = ? WHERE roomID = ?";
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement(updateQuery);
            prst.setString(1, room.getRoomType());
            prst.setString(2, room.getRoomPatient());
            prst.setString(3, room.getAppointedDoctor());
            prst.setString(4, room.getPatientProblem());
            prst.setInt(5, room.getRoomID());
            prst.executeUpdate();
            prst.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void dischargePatientAction(ActionEvent e) {
        String roomNo = txtRoomNo.getText();

        // Input validation
        if (roomNo.isEmpty()) {
            // Show error message or handle empty input
            System.out.println("Please fill the room number.");
            return;
        }

        try {
            int roomID = Integer.parseInt(roomNo);

            // Find the room in the list
            for (Room room : roomList) {
                if (room.getRoomID() == roomID) {
                    // Remove the room from the observable list
                    roomList.remove(room);

                    // Remove from the database
                    removeRoomFromDatabase(roomID);

                    // Refresh the table view
                    tableRoom.refresh();

                    // Clear input fields
                    txtRoomNo.clear();
                    txtRoomType.clear();
                    comboPatientInfo.getSelectionModel().clearSelection();
                    comboAppointedDoctor.getSelectionModel().clearSelection();
                    comboPatientProblem.getSelectionModel().clearSelection();

                    return;
                }
            }

            // If the room was not found
            System.out.println("Room not found. Please enter a valid room number.");

        } catch (NumberFormatException ex) {
            // Handle invalid input for room number
            System.out.println("Invalid room number. Please enter a valid number.");
        }
    }

    private void removeRoomFromDatabase(int roomID) {
        String deleteQuery = "DELETE FROM room WHERE roomID = ?";
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement(deleteQuery);
            prst.setInt(1, roomID);
            prst.executeUpdate();
            prst.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        roomList = FXCollections.observableArrayList();
        patientList = FXCollections.observableArrayList();
        doctorList = FXCollections.observableArrayList();
        patientProblemList = FXCollections.observableArrayList();
        loadRoomTable();
        loadRoomData();
        loadPatientNames();
        loadDoctorNames();
        loadPatientProblems();
    }

    private void loadRoomTable() {
        roomID.setCellValueFactory(new PropertyValueFactory<>("roomID"));
        roomType.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        roomPatient.setCellValueFactory(new PropertyValueFactory<>("roomPatient"));
        appointedDoctor.setCellValueFactory(new PropertyValueFactory<>("appointedDoctor"));
        patientProblem.setCellValueFactory(new PropertyValueFactory<>("patientProblem"));
        tableRoom.setItems(roomList);
    }

    private void loadRoomData() {
        roomList.clear();
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement("SELECT * FROM room");
            rs = prst.executeQuery();
            while (rs.next()) {
                roomList.add(new Room(rs.getInt("roomID"), rs.getString("roomType"),
                        rs.getString("roomPatient"), rs.getString("appointedDoctor"),
                        rs.getString("patientProblem")));
            }
            prst.close();
            rs.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadPatientNames() {
        patientList.clear();
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement("SELECT pFirst, pLast FROM patient");
            rs = prst.executeQuery();
            while (rs.next()) {
                String patientName = rs.getString("pFirst") + " " + rs.getString("pLast");
                patientList.add(patientName);
            }
            comboPatientInfo.setItems(patientList);
            prst.close();
            rs.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadDoctorNames() {
        doctorList.clear();
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement("SELECT drFirst, drLast FROM doctor");
            rs = prst.executeQuery();
            while (rs.next()) {
                String doctorName = rs.getString("drFirst") + " " + rs.getString("drLast");
                doctorList.add(doctorName);
            }
            comboAppointedDoctor.setItems(doctorList);
            prst.close();
            rs.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadPatientProblems() {
        patientProblemList.clear();
        try {
            conn = DBConnect.getConnection();
            prst = conn.prepareStatement("SELECT DISTINCT pProblem FROM patient");
            rs = prst.executeQuery();
            while (rs.next()) {
                String patientProblem = rs.getString("pProblem");
                patientProblemList.add(patientProblem);
            }
            comboPatientProblem.setItems(patientProblemList);
            prst.close();
            rs.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
