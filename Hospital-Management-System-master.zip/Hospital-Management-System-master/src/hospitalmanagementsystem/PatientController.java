package hospitalmanagementsystem;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class PatientController implements Initializable {

    @FXML
    private TextField txtPatID;
    @FXML
    private TextField txtPatFirst;
    @FXML
    private TextField txtPatLast;
    @FXML
    private TextField txtPatAge;
    @FXML
    private Label displayGender;
    @FXML
    private ComboBox<String> CBoxProblem;
    @FXML
    private ComboBox<String> CBoxRoom;
    @FXML
    private ComboBox<String> CBoxDoctor;
    @FXML
    private Button checkInPatient;
    @FXML
    private Button updatePatient;
    @FXML
    private Button checkOutPatient;
    @FXML
    private Button goBack;
    @FXML
    private ToggleGroup genderGroup;

    @FXML
    private TableView<Patient> tablePatient;
    @FXML
    private TableColumn<Patient, Integer> col_patID;
    @FXML
    private TableColumn<Patient, String> col_patFirst;
    @FXML
    private TableColumn<Patient, String> col_patLast;
    @FXML
    private TableColumn<Patient, String> col_patGender;
    @FXML
    private TableColumn<Patient, Integer> col_patAge;
    @FXML
    private TableColumn<Patient, String> col_patProblem;
    @FXML
    private TableColumn<Patient, Integer> col_patRoom;
    @FXML
    private TableColumn<Patient, Integer> col_patDoctor;

    private Connection conn = null;
    private PreparedStatement post = null;
    private ResultSet rs = null;
    private ObservableList<Patient> patientList;

    ObservableList<String> problemList = FXCollections.observableArrayList(
            "Abdominal Pain",
            "Back Pain",
            "Breathing",
            "Chest Pain",
            "Headache",
            "Infection",
            "Laceration",
            "Stroke Symptoms",
            "Trauma"
    );

    ObservableList<String> roomList = FXCollections.observableArrayList(
            "1", "2", "3", "4", "5", "6", "7", "8", "9"
    );

    public void checkInAction(ActionEvent e) throws IOException {

        //declare strings
        String patientID = txtPatID.getText();
        String patientFirst = txtPatFirst.getText();
        String patientLast = txtPatLast.getText();
        String patientAge = txtPatAge.getText();
        String patientProblem = CBoxProblem.getValue();
        String patientRoom = CBoxRoom.getValue();
        String patientDoctor = CBoxDoctor.getValue();

        String patientGender = "";
        if (genderGroup.getSelectedToggle() != null) {
            RadioButton button = (RadioButton) genderGroup.getSelectedToggle();
            patientGender = button.getText();
        }

        displayGender.setText(patientGender);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DBConnect.getConnection();

            Statement stmt = conn.createStatement();

            String insertQuery = "SELECT pID FROM patient";

            post = conn.prepareStatement(insertQuery);
            rs = post.executeQuery();
            while (rs.next()) {
                String patID = rs.getString("pID");
                if (patID.equals(patientID)) {
                    MessagePopup.display("Checking in...", "SORRY! ID is taken. Try a new one.");
                    return;
                }
            }

            stmt.executeUpdate("INSERT INTO patient VALUES ('" + patientID + "', '"
                    + patientFirst + "','" + patientLast + "','" + patientAge + "','"
                    + patientGender + "','" + patientProblem + "', '" + patientRoom + "', '"
                    + patientDoctor + "')");

            updateRoomWithPatientName(Integer.parseInt(patientRoom), patientFirst + " " + patientLast);

            MessagePopup.display("Checking in...", "Patient has been checked into the hospital!");

            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
            MessagePopup.display("Checking in...", "Please enter a patient ID.");
        }

        loadPatientTable();
        loadPatientData();
    }

    private void updateRoomWithPatientName(int roomID, String patientName) {
        String updateRoomQuery = "UPDATE room SET roomPatient = ? WHERE roomID = ?";
        try {
            conn = DBConnect.getConnection();
            post = conn.prepareStatement(updateRoomQuery);
            post.setString(1, patientName);
            post.setInt(2, roomID);
            int result = post.executeUpdate();
            if (result == 1) {
                System.out.println("Room updated with patient name: " + patientName);
            } else {
                System.out.println("Failed to update room with patient name: " + patientName);
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(PatientController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updatePatientAction(ActionEvent e) throws IOException {

        String patientID = txtPatID.getText();
        String patientFirst = txtPatFirst.getText();
        String patientLast = txtPatLast.getText();
        String patientAge = txtPatAge.getText();
        String patientProblem = CBoxProblem.getValue();
        String patientRoom = CBoxRoom.getValue();
        String patientDoctor = CBoxDoctor.getValue();

        String patientGender = "";
        if (genderGroup.getSelectedToggle() != null) {
            RadioButton button = (RadioButton) genderGroup.getSelectedToggle();
            patientGender = button.getText();
        }
        displayGender.setText(patientGender);

        //SQL UPDATE query
        String updateQuery = "UPDATE patient "
                + "SET pFirst = ?, pLast = ?, pAge = ?, pGender = ?, pProblem = ?, roomID = ?, pDoctor = ? "
                + "WHERE pID = ? AND pID <> 0;";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DBConnect.getConnection();

            Statement stmt = conn.createStatement();
            post = conn.prepareStatement(updateQuery);
            post.setString(1, patientFirst);
            post.setString(2, patientLast);
            post.setString(3, patientAge);
            post.setString(4, patientGender);
            post.setString(5, patientProblem);
            post.setString(6, patientRoom);
            post.setString(7, patientDoctor);
            post.setString(8, patientID);

            int i = post.executeUpdate();
            if (i == 1) {
                MessagePopup.display("Updating...", "Update Complete!");
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }

        loadPatientTable();
        loadPatientData();
    }

    public void checkOutAction(ActionEvent e) throws IOException {

        String patientID = txtPatID.getText();

        String deleteQuery = "DELETE FROM patient WHERE pID = ?";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DBConnect.getConnection();

            Statement stmt = conn.createStatement();
            post = conn.prepareStatement(deleteQuery);
            post.setString(1, patientID);
            int i = post.executeUpdate();
            if (i == 1)
                MessagePopup.display("Checking out...", "Patient has been checked out of hospital!");

        } catch (Exception ex) {
            System.out.println(ex);
            MessagePopup.display("Checking out...", "This Patient ID doesn't exist.");
        }

        loadPatientTable();
        loadPatientData();
    }

    public void treatmentAction(ActionEvent e) throws IOException {

        String patientProblem = CBoxProblem.getValue();

        switch (patientProblem) {
            case "Abdominal Pain":
                MessagePopup.display("Abdominal Pain Treatment", "Acetaminophen, Antacid, Antibiotics");
                break;
            case "Back Pain":
                MessagePopup.display("Back Pain Treatment", "Narcotics, PT Exercise, Laminectomy");
                break;
            case "Breathing":
                MessagePopup.display("Breathing Treatment", "Inhaler, Nebulizers");
                break;
            case "Chest Pain":
                MessagePopup.display("Chest Pain Treatment", "Angioplasty, Blood Thinners, Bypass Surgery");
                break;
            case "Headache":
                MessagePopup.display("Headache Treatment", "Ibuprofen, Naproxen, Indomitable");
                break;
            case "Infection":
                MessagePopup.display("Infection Treatment", "Tests then prescribe Antibiotics");
                break;
            case "Laceration":
                MessagePopup.display("Laceration Treatment", "Put pressure to the bleeding, Clean injury");
                break;
            case "Stroke Symptoms":
                MessagePopup.display("Stroke Treatment", "Alteplase(tPA), Catheter to remove blood clot");
                break;
            case "Trauma":
                MessagePopup.display("Trauma Treatment", "Probably Surgery...");
                break;
            default:
                MessagePopup.display("Treatment...", "NONE!!");
        }
    }

    public void goBackAction(ActionEvent e) throws IOException {
        goBack.getScene().getWindow().hide();

        Stage back = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Welcome.fxml")));
        Scene scene = new Scene(root);
        back.setScene(scene);
        back.show();
        back.setResizable(false);
    }

    public void fillDoctorCBox() {
        try {
            ObservableList<String> fillDoctor = FXCollections.observableArrayList();
            String query = "SELECT * FROM doctor";
            conn = DBConnect.getConnection();
            post = conn.prepareStatement(query);
            rs = post.executeQuery();

            while (rs.next()) {
                fillDoctor.add("Dr. " + rs.getString("drLast"));
                CBoxDoctor.setItems(fillDoctor);
            }
            post.close();
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(hospitalmanagementsystem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        CBoxProblem.setItems(problemList);
        CBoxRoom.setItems(roomList);
        fillDoctorCBox();

        patientList = FXCollections.observableArrayList();

        loadPatientTable();
        loadPatientData();
    }

    private void loadPatientTable() {

        col_patID.setCellValueFactory(new PropertyValueFactory<>("pID"));
        col_patFirst.setCellValueFactory(new PropertyValueFactory<>("pFirst"));
        col_patLast.setCellValueFactory(new PropertyValueFactory<>("pLast"));
        col_patGender.setCellValueFactory(new PropertyValueFactory<>("pGender"));
        col_patAge.setCellValueFactory(new PropertyValueFactory<>("pAge"));
        col_patProblem.setCellValueFactory(new PropertyValueFactory<>("pProblem"));
        col_patRoom.setCellValueFactory(new PropertyValueFactory<>("roomID"));
        col_patDoctor.setCellValueFactory(new PropertyValueFactory<>("pDoctor"));

        tablePatient.setItems(patientList);
    }

    private void loadPatientData() {
        patientList.clear();
        try {
            conn = DBConnect.getConnection();
            post = conn.prepareStatement("SELECT * FROM patient");
            rs = post.executeQuery();
            while (rs.next()) {
                patientList.add(new Patient(rs.getInt("pID"), rs.getString("pFirst"),
                        rs.getString("pLast"), rs.getString("pGender"),
                        rs.getInt("pAge"), rs.getString("pProblem"),
                        rs.getInt("roomID"), rs.getString("pDoctor")));

            }
        } catch (SQLException ex) {
            Logger.getLogger(DoctorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
