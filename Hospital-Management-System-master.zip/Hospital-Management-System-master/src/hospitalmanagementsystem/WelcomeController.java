package hospitalmanagementsystem;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
public class WelcomeController implements Initializable {

    @FXML
    private Button doctorDetails;
    @FXML
    private Button patientDetails;
    @FXML
    private Button roomDetails;
    @FXML
    private Button logout;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    

    @FXML
    public void doctorButtonPushed(ActionEvent e) throws IOException {
        doctorDetails.getScene().getWindow().hide();
           
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Doctor.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    @FXML
    public void patientButtonPushed(ActionEvent e) throws IOException {
        patientDetails.getScene().getWindow().hide();
           
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Patient.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    @FXML
    public void roomButtonPushed(ActionEvent e) throws IOException {
        roomDetails.getScene().getWindow().hide();
           
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Room.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    @FXML
    public void logOutButtonPushed(ActionEvent e) throws IOException {
        logout.getScene().getWindow().hide();
           
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Login.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }
}