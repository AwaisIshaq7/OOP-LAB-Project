package hospitalmanagementsystem;

public class Application {
}
