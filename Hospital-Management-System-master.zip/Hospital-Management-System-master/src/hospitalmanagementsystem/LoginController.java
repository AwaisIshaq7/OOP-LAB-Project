package hospitalmanagementsystem;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {
    @FXML
    private TextField loginUsername;
    @FXML
    private PasswordField loginPassword;
    @FXML
    private Button login;
    @FXML
    private Button register;
    @FXML
    private Button forgotPW;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    public void loginAction(ActionEvent e) throws IOException{
        //get user input
        String username = loginUsername.getText().toString();
        String password = loginPassword.getText().toString();
        if(check(username,password)){
            MessagePopup.display("Login Status", "Login Success!");
             
            login.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Welcome.fxml")));
            stage.setTitle("Hospital Management System");
            stage.setScene(new Scene(root));
            stage.show();
            stage.setResizable(false);
        }
        else{
            MessagePopup.display("Login Status", "Username/password is wrong. Try again!");
        }
    }

    public static boolean check(String username, String password){
         PreparedStatement pst = null;
         ResultSet rs = null;
         String query = "SELECT username, password FROM admin WHERE username=? AND password=?";
         
         try{
             Class.forName("com.mysql.jdbc.Driver");
             Connection conn = DBConnect.getConnection();
             pst = conn.prepareStatement(query); 
             pst.setString(1,username);
             pst.setString(2,password);
             rs = pst.executeQuery();
             
             if(rs.next()){
                 return true;
             }
             else{
                 return false;
             }
         }catch (Exception e){
             return false;
         }
    }

    @FXML
    public void registerButtonPushed(ActionEvent e) throws IOException {
        register.getScene().getWindow().hide();
           
        Stage register = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Register.fxml")));
        Scene scene = new Scene(root);
        register.setScene(scene);
        register.show();
        register.setResizable(false);
    }
}
