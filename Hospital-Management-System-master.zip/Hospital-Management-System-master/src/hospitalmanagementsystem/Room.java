package hospitalmanagementsystem;

public class Room {

    int roomID;
    String roomType;
    String roomPatient;
    String appointedDoctor;
    String patientProblem;

    public Room(int roomID, String roomType, String roomPatient, String appointedDoctor, String patientProblem) {
        this.roomID = roomID;
        this.roomType = roomType;
        this.roomPatient = roomPatient;
        this.appointedDoctor = appointedDoctor;
        this.patientProblem = patientProblem;
    }

    public int getRoomID() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getRoomPatient() {
        return roomPatient;
    }

    public void setRoomPatient(String roomPatient) {
        this.roomPatient = roomPatient;
    }

    public String getAppointedDoctor() {
        return appointedDoctor;
    }

    public void setAppointedDoctor(String appointedDoctor) {
        this.appointedDoctor = appointedDoctor;
    }

    public String getPatientProblem() {
        return patientProblem;
    }

    public void setPatientProblem(String patientProblem) {
        this.patientProblem = patientProblem;
    }
}
